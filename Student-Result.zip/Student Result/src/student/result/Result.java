
package student.result;


public interface Result {
    float calculateGpa();
    void getSubject();
    void showResult();
    void setMarks(float mark1,float mark2);
}
